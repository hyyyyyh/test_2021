/*m-header侧边js*/

var MobilMenu = document.getElementById('m-header-menu');
var MobilMenuNum = -320;
function MobilMenuAnimationA(){
    MobilMenu.style.display ='';
    var MobilMenuTime = setInterval(MobilMenuAnimationB,5);
    function MobilMenuAnimationB(){
        if(MobilMenuNum == 0){
            clearInterval(MobilMenuTime);
        }
        else{
            MobilMenuNum = MobilMenuNum + 10;
            MobilMenu.style.right = MobilMenuNum + 'px';
        }
    };
};