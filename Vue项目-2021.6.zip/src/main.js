import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import Scrollspy from 'vue2-scrollspy';

import BootstrapVue from 'bootstrap-vue'
import VueParticles from 'vue-particles' //粒子特效
import VueResource from "vue-resource";

var VueScrollTo = require('vue-scrollto');

Vue.use(VueParticles)
Vue.use(VueScrollTo)

Vue.use(BootstrapVue);

Vue.use(Scrollspy);
Vue.config.productionTip = false;
Vue.use(VueResource)

new Vue({
  router,
  render: h => h(App)
}).$mount("#app");
