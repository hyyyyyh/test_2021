import Vue from "vue";
import VueRouter from "vue-router";

import Index1 from "./pages/index1.vue";
import Index2 from "./pages/index2.vue";
import Index3 from "./pages/index3.vue";
import Index4 from "./pages/index4.vue";
import Login from "./pages/login.vue";
import Signup from "./pages/signup.vue";
import Forgotpassword from './pages/password-forgot.vue';

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Index-1",
    component: Index1
  },
  {
    path: "/index-1",
    component: Index1
  },
  {
    path: "/index-2",
    name: "Index-2",
    component: Index2
  },
  {
    path: "/index-3",
    name: "Index-3",
    component: Index3
  },
  {
    path: "/index-4",
    name: "Index-4",
    component: Index4
  },
  {
    path: "/login",
    name: "Login page",
    component: Login
  },
  {
    path: "/signup",
    name: "Signup page",
    component: Signup
  },
  {
    path: '/password_forgot',
    name: 'Forgot Password page',
    component: Forgotpassword
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
