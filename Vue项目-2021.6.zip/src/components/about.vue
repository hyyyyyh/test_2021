<script>
/**
 * About component
 */
export default {
  name: 'About',
  data(){
    return{
      "abouts":[]
    }
  },
  created(){
    this.$http.get("http://rap2api.taobao.org/app/mock/285501/about/get").then((about)=>{
      this.abouts = about.data.abouts
    })
  }

}
</script>

<template>
  <!--START ABOUT-US-->
  <section class="section" id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <div class="about-title mx-auto text-center">
            <h2
              class="font-weight-light"
            >数字化网络工作室 &amp; 参与在线体验</h2>
            <p
              class="text-muted pt-4"
            >拥有专业的网页设计团队</p>
          </div>
        </div>
      </div>
      <div class="row margin-t-50">
        <div class="col-lg-3 col-sm-6" v-for="about in abouts" :key="about">
          <div class="team-box text-center">
            <div class="team-wrapper">
              <div class="team-member">
                <img alt :src="about.img" class="img-fluid rounded" />
              </div>
            </div>
            <h4 class="team-name">{{about.name}}</h4>
            <p class="text-uppercase team-designation">{{about.dir}}</p>
          </div>
        </div>

       
      </div>
    </div>
  </section>
  <!--END ABOUT-US-->
</template>