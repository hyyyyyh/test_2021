

<template>
  <!--START TESTIMONIAL-->
  <section class="section" id="testi">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <h1 class="section-title text-center">用户评论</h1>
          <div class="section-title-border margin-t-20"></div>
          <p
            class="section-subtitle text-muted text-center font-secondary padding-t-30"
          ></p>
        </div>
      </div>
      <div class="row margin-t-50">
        <div class="col-lg-4" v-for="comment in comments" v-bind:key="comment">
          <div class="testimonial-box margin-t-30">
            <div class="testimonial-decs p-4">
              <div class="testi-icon">
                <i class="mdi mdi-format-quote-open display-2"></i>
              </div>
              <img
                :src="comment.image"
                class="img-fluid mx-auto d-block img-thumbnail rounded-circle mb-4"
              />
              <div class="p-1">
                <h5 class="text-center text-uppercase mb-3">
                  {{comment.name}} -
                </h5>
                <p
                  class="text-muted text-center mb-0"
                >“{{comment.text}}”</p>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="col-lg-4">
          <div class="testimonial-box margin-t-30">
            <div class="testimonial-decs p-4">
              <div class="testi-icon">
                <i class="mdi mdi-format-quote-open display-2"></i>
              </div>
              <img
                src="@/assets/images/testimonials/user-2.jpg"
                alt
                class="img-fluid mx-auto d-block img-thumbnail rounded-circle mb-4"
              />
              <div class="p-1">
                <h5 class="text-center text-uppercase mb-3">
                  杨鹏 -
                  <span class="text-muted text-capitalize"></span>
                </h5>
                <p
                  class="text-muted text-center mb-0"
                >“感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错”</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="testimonial-box margin-t-30">
            <div class="testimonial-decs p-4">
              <div class="testi-icon">
                <i class="mdi mdi-format-quote-open display-2"></i>
              </div>
              <img
                src="@/assets/images/testimonials/user-3.jpg"
                alt
                class="img-fluid mx-auto d-block img-thumbnail rounded-circle mb-4"
              />
              <div class="p-1">
                <h5 class="text-center text-uppercase mb-3">
                  杨鹏 -
                  <span class="text-muted text-capitalize"></span>
                </h5>
                <p
                  class="text-muted text-center mb-0"
                >“感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错感觉非常不错”</p>
              </div>
            </div>
          </div>
        </div> -->
      </div>
    </div>
  </section>
  <!--END TESTIMONIAL-->
</template>
<script>

export default {
  name: 'Testimonial',
  data(){
    return{
      comments:[],
    }
  },
  methods:{

  },
  components:{},
  created(){
    this.$http.get("http://rap2api.taobao.org/app/mock/285501/comment/get").then((res)=>{
      this.comments = res.data.comment
    })
  }
}
</script>