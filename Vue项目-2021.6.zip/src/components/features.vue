<script>
/**
 * Features component
 */
export default {
  name: 'Features',
  data() {
    return{
      "features":[]
    }
  },
  created(){
    this.$http.get("http://rap2api.taobao.org/app/mock/285501/features/get").then((features)=>{
      this.features = features.data.features
    })
  }
};

</script>

<template>
  <!--START FEATURES-->
  <section class="section" id="features">
    <div class="container" v-for="feature in features" :key="feature">
      <div class="row align-items-center">
        <div class="col-lg-5 order-2 order-lg-1">
          <div class="features-box mt-5 mt-lg-0">
            <h3>{{ feature.title }}</h3>
            <p
              class="text-muted web-desc"
            >{{ feature.text }}</p>
            <ul class="text-muted list-unstyled margin-t-30 features-item-list">
              <li class v-for="li in feature.ul" :key="li">{{ li.li }}</li>
            </ul>
            <a href="#" class="btn btn-custom margin-t-30">
              了解更多
              <i class="mdi mdi-arrow-right"></i>
            </a>
          </div>
        </div>
        <div class="col-lg-7 order-1 order-lg-2">
          <div class="features-img mx-auto mr-lg-0">
            <img src="@/assets/images/growth-analytics.svg" alt="macbook image" class="img-fluid" />
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--END FEATURES-->
</template>