<template>
  <!--START PRICING-->
  <section class="section bg-light" id="pricing">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <h1 class="section-title text-center">超低价格</h1>
          <div class="section-title-border margin-t-20"></div>
          <p
            class="
              section-subtitle
              font-secondary
              text-muted text-center
              padding-t-30
            "
          >
            云速建站满减优惠礼包
          </p>
        </div>
      </div>
      <div class="row margin-t-50">
        <div class="col-lg-4" v-for="price in prices" :key="price">
          <div class="text-center pricing-box">
          <div class="ribbon-box"  v-show="price.is_hot == 1"><span>热门</span></div>
            <h4 class="text-uppercase">{{price.name}}</h4>
            <h1>￥{{price.price}}</h1>
            <h6 class="text-uppercase text-muted">每月计费</h6>
            <div class="plan-features margin-t-50">
              <p>
                带宽
                <b class="text-custom">{{price.bandwidth}}GB</b>
              </p>
              <p>
                在线空间
                <b class="text-custom">{{price.supportsize}}MB</b>
              </p>
              <p>
                在线支持
                <b class="text-custom">{{price.support}}</b>
              </p>
              <p><b class="text-custom">{{price.domin}}</b> 个域</p>
              <p><b class="text-custom">无</b> 隐藏费用</p>
            </div>
            <a href="#" class="btn btn-custom margin-t-30">立即购买</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--ENd PRICING-->
</template>


<script>
export default {
  name: "Pricing",
  data(){

    return {
      prices:[]
    }
  },
  created(){
    this.$http.get("http://rap2api.taobao.org/app/mock/285501/price/get").then((res)=>{
      this.prices = res.data.price
    })
  }
};
</script>