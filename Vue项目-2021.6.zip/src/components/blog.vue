<script>
/**
 * Blog component
 */
export default {
  name: 'Blog',
  data(){
    return{
      blogs:[]
    }
  },
  methods:{

  },
  components:{},
  created(){
    this.$http.get("http://rap2api.taobao.org/app/mock/285501/blog/get").then((res)=>{
      this.blogs = res.data.blog
    })
  }
}
</script>

<template>
  <section class="section bg-light" id="blog">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 offset-lg-2">
          <h1 class="section-title text-center">最新消息</h1>
          <div class="section-title-border margin-t-20"></div>
          <p
            class="section-subtitle text-muted text-center font-secondary padding-t-30"
          ></p>
        </div>
      </div>

      <div class="row margin-t-30">
        <div class="col-lg-4" v-for="blog in blogs" :key="blog">
          <div class="blog-box margin-t-30">
            <img :src="blog.img" class="img-fluid rounded" alt />
            <div>
              <h5 class="mt-4 text-muted">{{blog.username}}</h5>
              <h4 class="mt-3">
                <a href class="blog-title">{{blog.title}}</a>
              </h4>
              <p
                class="text-muted"
              >{{blog.text}}</p>
              <div class="mt-3">
                <a href class="read-btn">
                  Read More
                  <i class="mdi mdi-arrow-right"></i>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- END BLOG -->
</template>