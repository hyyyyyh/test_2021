<script>
export default {
  name: 'Services',
  data(){
    return{
    }
  }
}
</script>

<template>
  <div>
    <!--START SERVICES-->
    <section class="section bg-light" id="services">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 offset-lg-2">
            <h1 class="section-title text-center">服务亮点</h1>
            <div class="section-title-border margin-t-20"></div>
            <p
              class="section-subtitle text-muted text-center padding-t-30 font-secondary"
            >企业版专享华为云资源加持，独享10M带宽、独立IP、无限云空间，支持华为云CDN加速等，让网站性能更强</p>
          </div>
        </div>
        <div class="row margin-t-30">
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-diamond text-custom"></i>
                <div class="media-body ml-4">
                  <h4>五站合一，轻松搞定PC+移动端</h4>
                  <p
                    class="pt-2 text-muted"
                  >云速建站支持PC、手机、小程序、微信公众号、App一站式搭建，助力企业移动互联网全场景营销</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-display2 text-custom"></i>
                <div class="media-body ml-4">
                  <h4>70+控件让网站更丰富，营销更简单</h4>
                  <p
                    class="pt-2 text-muted"
                  >70+种丰富插件，覆盖图片、文字、会员、表单、地图、在线咨询、视频，及基础电商功能等</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-piggy text-custom"></i>
                <div class="media-body ml-4">
                  <h4>支持14种交易支付方式</h4>
                  <p
                    class="pt-2 text-muted"
                  >配备支付宝、微信等14种主流支付方式，基础的商品管理、订单管理、物流配送管理等，实现轻量线上交易</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-science text-custom"></i>
                <div class="media-body ml-4">
                  <h4>专属云资源，让网站性能更强大</h4>
                  <p
                    class="pt-2 text-muted"
                  >企业版专享华为云资源加持，独享10M带宽、独立IP、无限云空间，支持华为云CDN加速等，让网站性能更强</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-news-paper text-custom"></i>
                <div class="media-body ml-4">
                  <h4>3000+模板及素材库</h4>
                  <p
                    class="pt-2 text-muted"
                  >7大色系、60+行业覆盖、3000+现成模板、100000+图片库，像做PPT一样轻松搭建网站</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-plane text-custom"></i>
                <div class="media-body ml-4">
                  <h4>多种SEO功能，让更多客户找到您</h4>
                  <p
                    class="pt-2 text-muted"
                  >支持TKD设置、301重定向、伪静态设置等多种SEO功能，有效提升搜索引擎对网站的收录及排名</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-arc text-custom"></i>
                <div class="media-body ml-4">
                  <h4>网站安全，华为云保驾护航</h4>
                  <p
                    class="pt-2 text-muted"
                  >支持HTTPS使网站防劫持、防篡改、防监听。客户更加信任您</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-tools text-custom"></i>
                <div class="media-body ml-4">
                  <h4>香港节点免备案，助力企业出海</h4>
                  <p
                    class="pt-2 text-muted"
                  >支持香港节点免备案，境外访问更快捷，支持PayPal、支付宝境外币种等支付方式，让中小企业出海推广更简单</p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4 margin-t-20">
            <div class="services-box">
              <div class="media">
                <i class="pe-7s-timer text-custom"></i>
                <div class="media-body ml-4">
                  <h4>独一无二的设计</h4>
                  <p
                    class="pt-2 text-muted"
                  >支持TKD设置、301重定向、伪静态设置等多种SEO功能，有效提升搜索引擎对网站的收录及排名</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--START SERVICES-->

    <!--START WEBSITE-DESCRIPTION-->
    <section
      class="section bg-web-desc"
      :style="{'background-image': 'url(' + require('@/assets/images/img-1.jpg') + ')', 'background-size': 'cover','background-position': 'center'}"
    >
      <div class="bg-overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="text-white">建造你的梦想网站</h2>
            <p
              class="padding-t-15 home-desc mx-auto"
            >模板覆盖电商/互联网/工业/教育/餐饮等60+行业，不用懂代码，选择模板，PPT式拖拽编辑，快速搭建网站</p>
            <a
              href="#"
              class="btn btn-bg-white margin-t-30"
            >查看计划</a>
          </div>
        </div>
      </div>
    </section>
    <!--END WEBSITE-DESCRIPTION-->
  </div>
</template>